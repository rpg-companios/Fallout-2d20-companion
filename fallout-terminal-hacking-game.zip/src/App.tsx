import React, { useState, useEffect, useCallback } from 'react';

const SYMBOLS = "!@#$%^&*()-=_+[]{}|;':\",./<>?";
const BRACKET_PAIRS = [['(', ')'], ['[', ']'], ['<', '>'], ['{', '}']];

// Sets of words of varying lengths (5, 6, 7, 8, 9)
const WORD_SETS = [
  // 5 letters
  ["ABOUT", "AFTER", "AGAIN", "BELOW", "BOARD", "CATCH", "CHAIR", "CLASS", "CLOSE", "DEATH", "EIGHT", "EVERY", "FIRST", "FOUND", "GREAT", "HEART", "HOUSE", "LARGE", "LEARN", "LEAVE"],
  // 6 letters
  ["BATTLE", "BEHIND", "BETTER", "BOTTLE", "BUTTON", "CANCER", "CASTLE", "CATTLE", "CHANCE", "CHANGE", "CHARGE", "CHOOSE", "CHURCH", "CIRCLE", "CLEARE", "CLINIC", "COMMON", "COURSE", "CREATE"],
  // 7 letters
  ["AGAINST", "ALREADY", "ANOTHER", "BECAUSE", "BELIEVE", "BETWEEN", "BROTHER", "BROUGHT", "CERTAIN", "CHANGED", "CHAPTER", "CHILDRE", "COMMAND", "COMPANY", "CONTROL", "COUNTRY", "DISEASE", "EVENING", "EXAMPLE"],
  // 8 letters
  ["ALTHOUGH", "AMERICAN", "ANYTHING", "APPROACH", "BUSINESS", "CAMPAIGN", "CHILDREN", "COMPLETE", "COMPUTER", "CONTINUE", "CULTURAL", "DAUGHTER", "DECISION", "DIRECTOR", "DISCOVER", "ECONOMIC", "ELECTION", "EMPLOYEE", "EVERYONE"],
  // 9 letters
  ["AGREEMENT", "ATTENTION", "BEAUTIFUL", "CHARACTER", "COLLECTIO", "COMMITTEE", "COMMUNITY", "CONDITION", "DIFFERENT", "DIRECTION", "DISCOVERY", "EDUCATION", "EVALUATIO", "EXECUTIVE", "IMPORTANT", "KNOWLEDGE", "NECESSARY", "POLITICAL", "PRESIDENT"]
];

type CellData = {
  char: string;
  isWord?: boolean;
  wordIndex?: number;
  isOpeningBracket?: boolean;
  isClosingBracket?: boolean;
  bracketId?: string;
};

export default function App() {
  const [gameState, setGameState] = useState<'playing' | 'won' | 'lost'>('playing');
  const [words, setWords] = useState<string[]>([]);
  const [password, setPassword] = useState('');
  const [board, setBoard] = useState<CellData[]>([]);
  const [attempts, setAttempts] = useState(4);
  const [dudsRemoved, setDudsRemoved] = useState<number[]>([]);
  const [usedBrackets, setUsedBrackets] = useState<string[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [baseHex, setBaseHex] = useState(0);

  // Hover states
  const [hoveredWordIndex, setHoveredWordIndex] = useState<number | null>(null);
  const [hoveredBracketId, setHoveredBracketId] = useState<string | null>(null);
  const [hoverCursorIdx, setHoverCursorIdx] = useState<number | null>(null);

  const initGame = useCallback(() => {
    // 1. Pick a random word set
    const setIdx = Math.floor(Math.random() * WORD_SETS.length);
    const wordSet = [...WORD_SETS[setIdx]].sort(() => Math.random() - 0.5);
    
    // 2. Pick 12 words
    const selectedWords = wordSet.slice(0, 12);
    const pass = selectedWords[Math.floor(Math.random() * selectedWords.length)];
    
    setWords(selectedWords);
    setPassword(pass);
    setAttempts(4);
    setDudsRemoved([]);
    setUsedBrackets([]);
    setGameState('playing');
    setLogs([]);
    setBaseHex(0xF600 + Math.floor(Math.random() * 0x100));

    // 3. Initialize board of size 408 (17 rows * 12 chars * 2 cols)
    const newBoard: CellData[] = Array(408).fill(null);

    // Place words
    selectedWords.forEach((word, wordIndex) => {
      let placed = false;
      let attemptsCounter = 0;
      while (!placed && attemptsCounter < 1000) {
        attemptsCounter++;
        const start = Math.floor(Math.random() * (408 - word.length));
        
        let empty = true;
        for (let i = 0; i < word.length; i++) {
          if (newBoard[start + i] !== null) {
            empty = false;
            break;
          }
        }
        
        if (empty) {
          for (let i = 0; i < word.length; i++) {
            newBoard[start + i] = {
              char: word[i],
              isWord: true,
              wordIndex,
            };
          }
          placed = true;
        }
      }
    });

    // Place brackets (4 to 7)
    const numBrackets = Math.floor(Math.random() * 4) + 4;
    let bracketIdCounter = 0;
    
    for (let i = 0; i < numBrackets; i++) {
      let placed = false;
      let attemptsCounter = 0;
      
      while (!placed && attemptsCounter < 100) {
        attemptsCounter++;
        const line = Math.floor(Math.random() * 34); // 34 lines total
        const startX = Math.floor(Math.random() * 10);
        const endX = startX + 1 + Math.floor(Math.random() * (11 - startX));
        
        const startIdx = line * 12 + startX;
        const endIdx = line * 12 + endX;
        
        let empty = true;
        for (let j = startIdx; j <= endIdx; j++) {
          if (newBoard[j] !== null) {
            empty = false;
            break;
          }
        }
        
        if (empty) {
          const pair = BRACKET_PAIRS[Math.floor(Math.random() * BRACKET_PAIRS.length)];
          const bId = `bracket-${bracketIdCounter++}`;
          
          newBoard[startIdx] = { char: pair[0], bracketId: bId, isOpeningBracket: true };
          newBoard[endIdx] = { char: pair[1], bracketId: bId, isClosingBracket: true };
          
          for (let j = startIdx + 1; j < endIdx; j++) {
            newBoard[j] = { 
              char: SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], 
              bracketId: bId 
            };
          }
          placed = true;
        }
      }
    }

    // Fill the rest with random symbols
    for (let i = 0; i < 408; i++) {
      if (newBoard[i] === null) {
        newBoard[i] = { char: SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)] };
      }
    }

    setBoard(newBoard);
  }, []);

  useEffect(() => {
    initGame();
  }, [initGame]);

  const handleMouseEnter = (index: number) => {
    if (gameState !== 'playing') return;
    
    const cell = board[index];
    if (cell.isWord && cell.wordIndex !== undefined && !dudsRemoved.includes(cell.wordIndex)) {
      setHoveredWordIndex(cell.wordIndex);
      setHoveredBracketId(null);
      setHoverCursorIdx(null);
    } else if (cell.isOpeningBracket && cell.bracketId && !usedBrackets.includes(cell.bracketId)) {
      setHoveredBracketId(cell.bracketId);
      setHoveredWordIndex(null);
      setHoverCursorIdx(null);
    } else {
      setHoverCursorIdx(index);
      setHoveredWordIndex(null);
      setHoveredBracketId(null);
    }
  };

  const handleMouseLeaveGrid = () => {
    setHoveredWordIndex(null);
    setHoveredBracketId(null);
    setHoverCursorIdx(null);
  };

  const handleClick = (index: number) => {
    if (gameState !== 'playing') return;

    const cell = board[index];

    // Clicking a word
    if (cell.isWord && cell.wordIndex !== undefined && !dudsRemoved.includes(cell.wordIndex)) {
      const word = words[cell.wordIndex];
      
      if (word === password) {
        setGameState('won');
        setLogs(prev => [...prev, `>${word}`, `>Exact match!`, `>Please wait...`, `>System login successful.`]);
      } else {
        let likeness = 0;
        for (let i = 0; i < word.length; i++) {
          if (word[i] === password[i]) likeness++;
        }
        
        const newAttempts = attempts - 1;
        setAttempts(newAttempts);
        setLogs(prev => [...prev, `>${word}`, `>Entry denied`, `>Likeness=${likeness}`]);
        
        if (newAttempts === 0) {
          setGameState('lost');
          setLogs(prev => [...prev, `>Init lockout...`].slice(-12));
        } else {
          setLogs(prev => prev.slice(-12));
        }
      }
    } 
    // Clicking a bracket
    else if (cell.isOpeningBracket && cell.bracketId && !usedBrackets.includes(cell.bracketId)) {
      const bId = cell.bracketId;
      const bracketCells = board.filter(c => c.bracketId === bId);
      const bracketStr = bracketCells.map(c => c.char).join('');
      
      setUsedBrackets(prev => [...prev, bId]);
      
      const isReset = Math.random() < 0.2;
      
      if (isReset) {
        setAttempts(4);
        setLogs(prev => [...prev, `>${bracketStr}`, `>Tries Reset.`].slice(-12));
      } else {
        const availableDuds = words.map((w, idx) => ({ w, idx }))
                                   .filter(item => item.w !== password && !dudsRemoved.includes(item.idx));
        
        if (availableDuds.length > 0) {
          const dud = availableDuds[Math.floor(Math.random() * availableDuds.length)];
          setDudsRemoved(prev => [...prev, dud.idx]);
          setLogs(prev => [...prev, `>${bracketStr}`, `>Dud Removed.`].slice(-12));
        } else {
          setLogs(prev => [...prev, `>${bracketStr}`, `>No duds left.`].slice(-12));
        }
      }
    }
  };

  const renderCell = (cell: CellData, index: number) => {
    const isDudRemoved = cell.isWord && cell.wordIndex !== undefined && dudsRemoved.includes(cell.wordIndex);
    let displayChar = cell.char;
    if (isDudRemoved) {
      displayChar = '.';
    }

    const isHoveredWord = cell.isWord && cell.wordIndex === hoveredWordIndex && !isDudRemoved;
    const isHoveredBracket = cell.bracketId && cell.bracketId === hoveredBracketId && !usedBrackets.includes(cell.bracketId);
    const isHoveredChar = hoverCursorIdx === index;
    
    const isHighlighted = isHoveredWord || isHoveredBracket || isHoveredChar;

    return (
      <span
        key={index}
        onMouseEnter={() => handleMouseEnter(index)}
        onClick={() => handleClick(index)}
        className={`inline-block w-[1.2ch] text-center cursor-pointer select-none ${
          isHighlighted ? 'bg-[#16c60c] text-[#050505]' : ''
        }`}
      >
        {displayChar}
      </span>
    );
  };

  // Prepare left and right columns
  const leftCol: React.ReactNode[] = [];
  const rightCol: React.ReactNode[] = [];

  for (let i = 0; i < 17; i++) {
    const leftHex = `0x${(baseHex + i * 12).toString(16).toUpperCase()}`;
    const rightHex = `0x${(baseHex + (i + 17) * 12).toString(16).toUpperCase()}`;
    
    const leftCells = board.slice(i * 12, (i + 1) * 12);
    const rightCells = board.slice((i + 17) * 12, (i + 18) * 12);

    leftCol.push(
      <div key={`L${i}`} className="flex gap-4">
        <span>{leftHex}</span>
        <span>
          {leftCells.map((c, idx) => renderCell(c, i * 12 + idx))}
        </span>
      </div>
    );
    
    rightCol.push(
      <div key={`R${i}`} className="flex gap-4">
        <span>{rightHex}</span>
        <span>
          {rightCells.map((c, idx) => renderCell(c, (i + 17) * 12 + idx))}
        </span>
      </div>
    );
  }

  // Calculate Hovered Text
  let currentHoverText = '';
  if (hoveredWordIndex !== null) {
    currentHoverText = words[hoveredWordIndex];
  } else if (hoveredBracketId !== null) {
    currentHoverText = board.filter(c => c.bracketId === hoveredBracketId).map(c => c.char).join('');
  } else if (hoverCursorIdx !== null) {
    const cell = board[hoverCursorIdx];
    currentHoverText = (cell.isWord && cell.wordIndex !== undefined && dudsRemoved.includes(cell.wordIndex)) ? '.' : cell.char;
  }

  return (
    <div className="min-h-screen bg-[#050505] text-[#16c60c] p-4 md:p-8 font-mono text-xl md:text-2xl crt-glow relative selection:bg-[#16c60c] selection:text-[#050505]">
      <div className="scanline"></div>
      
      <div className="max-w-6xl mx-auto flex flex-col gap-4 relative z-10">
        <header className="mb-4 space-y-2">
          <p>ROBCO INDUSTRIES (TM) TERMLINK PROTOCOL</p>
          <p>ENTER PASSWORD NOW</p>
          <div className="mt-4 flex items-center gap-4">
            <p>{attempts} ATTEMPT(S) LEFT: </p>
            <div className="flex gap-2">
              {[...Array(attempts)].map((_, i) => (
                <span key={i}>■</span>
              ))}
            </div>
          </div>
        </header>

        <div className="flex flex-col lg:flex-row gap-8 items-start">
          
          <div 
            className="flex flex-col md:flex-row gap-8"
            onMouseLeave={handleMouseLeaveGrid}
          >
            <div className="flex flex-col">
              {leftCol}
            </div>
            <div className="flex flex-col">
              {rightCol}
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-end min-h-[400px]">
            <div className="flex flex-col items-end w-full space-y-1">
              {logs.slice(-12).map((log, idx) => (
                <p key={idx} className="w-full text-right">{log}</p>
              ))}
              
              {gameState === 'playing' ? (
                <p className="w-full text-right mt-4">{`> ${currentHoverText}`}<span className="animate-pulse">_</span></p>
              ) : (
                <div className="w-full flex justify-end mt-8">
                  <button 
                    onClick={initGame}
                    className="border border-[#16c60c] px-4 py-2 hover:bg-[#16c60c] hover:text-[#050505] transition-colors uppercase"
                  >
                    Reboot Terminal
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}